Veilfall Earth 240x120 - Test Game Historical Start Map

1. Unzip this archive.
2. Copy the enclosed map file (without file extension) into the Unciv maps directory, or Veilfall mod's maps directory.
3. Start a new game with Veilfall enabled; choose Custom Map / Veilfall Earth 240x120 - Test Game TSL.
4. Choose Select players from starting locations for the historical civilization roster.
5. Game load and Android performance have NOT yet been tested.

Map dimensions: 240 x 120 (28,800 tiles), world wrap. 10 major civilizations and eight city-states are marked.
