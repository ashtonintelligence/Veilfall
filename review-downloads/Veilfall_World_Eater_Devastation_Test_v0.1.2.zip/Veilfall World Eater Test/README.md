# Veilfall — The World-Eater (v0.1.2-test: ownership preserved)

Experimental companion mod for Unciv **4.22.17**; requires the Veilfall base mod.

## What is actually implemented by this ZIP

- **Unable to capture cities**: world-eater attacks leave a defeated city with its original owner. This is a built-in Unciv unit unique.
- Defeated cities bottom out at **1 HP**, which Unciv also treats as **1 defending strength** regardless of nominal city strength and defensive buildings.
- The earlier unique that instantly destroyed non-capital cities remains REMOVED.
- The existing monster art, land/sea movement, strength 3000, three attacks per turn, healing and improvement damage remain unchanged.
- World-Eater remains a **scenario unit** with no extra starting companions.

## Design specified but NOT YET AUTOMATED in this standard mod

On the **first** monster attack that drives a particular city to 1 HP:

- Original city owner stays the same.
- Population survivors = max(1, floor(population_before_hit / 2)). Thus 19 becomes 9, 12 becomes 6, and 1 remains 1.
- For EACH existing building, independently calculate a 50% loss probability. This is not a blanket 50% of the building count; stochastic losses vary per city.
- Remove defending garrison/air units as separately specified.
- Capital/Palace and engine-invariant buildings require a safe 'ruined' state if a selected building cannot be removed without invalidating game logic. Standard mod has no such state; no building loss is simulated or applied by this ZIP.
- Destroy the city zero times: no ownership transfer, razing, or disappearance.

A normal Unciv extension ruleset has no unit-attack hook able to modify **the enemy city's population and individually iterate its buildings**. Implementing these effects when a city is devastated requires an engine change or a sanctioned extension hook. DO NOT confuse the rules below with implemented features.

## Caveats

- This standard mod does **not** implement guaranteed immunity to non-nuclear weapons.
- The city automatically heals 20 HP at turn end under Unciv 4.22.17; thus 1-HP vulnerability persists immediately but does not remain permanent without an additional engine-side cooldown.
- The nearby city garrison and aircraft are NOT automatically destroyed by this non-capture attack (Unciv destroys them on actual conquest). This is another future engine-side feature.
- Scenario save remains **Crash_Site_The_World_Eater_Turn_Zero.json** with the 164 established cities and one monster. No save modification is needed.
- No in-game Android test of this specific ZIP yet.
- No changes to Veilfall main, original saves, or the accepted drone build.

## Acceptance tests

1. Load the turn-zero scenario with both Veilfall and World Eater Test mods installed. Verify one World-Eater.
2. Attack an enemy city until it is at 1 HP. Verify original owner retains the city and it still appears on the map.
3. Verify defending strength reads 1 during a subsequent attack and that another attacking civilization could capture it.
4. Verify population and builtBuildings have NOT silently been modified by the prototype; these effects remain unimplemented.
