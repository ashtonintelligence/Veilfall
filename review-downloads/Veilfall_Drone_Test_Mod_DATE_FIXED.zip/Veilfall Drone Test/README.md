# Veilfall Drone Test — isolated companion mod

This is a **test-only** extension that loads alongside the existing `Veilfall` mod.
It adds two drones, their sprite/icon/portrait atlas, and replaces only the complete
Ashton nation definition to apply crimson-and-gold colors. It does not override or
remove The Pale Horseman, Azazel, or any other existing units.

Use the supplied `Crash_Site_Drone_Test_Start_2x2.json` save, which explicitly
lists `Veilfall` and `Veilfall Drone Test` in that order. DO NOT load the older
single-mod save with the new units: it lacks this test extension in its mod list.

Install to Unciv's mods folder as a directory **exactly** named
`Veilfall Drone Test`, with `jsons/` immediately inside that directory.
On Android this may require copying via a computer or a file manager with
Android/data access; see the companion test instructions.

Do not upload/merge into the production Veilfall repo. This add-on is temporary.
This package is not yet in-game verified; check unit art, movement, stealth,
combat, and save/reload before considering it production-ready.
