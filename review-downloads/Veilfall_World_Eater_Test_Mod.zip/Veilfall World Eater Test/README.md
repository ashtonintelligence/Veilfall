# Veilfall — The World-Eater (experimental companion mod)

This first test mod is for Unciv 4.22.17 and requires the base **Veilfall** mod. It adds one Ashton-only **The World-Eater** creature, 3,000 melee strength (10× Pale Horseman), three attacks, a massive on-map sprite, all-terrain/water access, and an ability to **destroy ordinary cities instead of capturing them**. Unit cannot be trained or purchased.

**IMPORTANT MECHANICAL LIMITS:**
- Exact **nuclear-only vulnerability** is NOT enforceable by the ordinary Unciv extension ruleset; the prototype uses 3,000 defense and strong recovery so conventional warfare is almost certainly ineffective, but not mathematically impossible.
- The native `Destroys [in all cities] cities instead of capturing` rule **cannot destroy original capital cities or city-state capitals**. These are captured normally. Exact -10 population, remove every building, and kill every civilian in capitals is NOT implemented.
- Destruction removes the entire ordinary city (all residents and buildings), rather than leaving a conquered 1-population shell.
- City destruction is supported natively, but this has NOT passed fresh in-game acceptance.
- Prototype icon/sprite art comes from the pixel sprite on the generated concept sheet; it is not finalized original transparent master art.

**Scenario**: `Crash_Site_The_World_Eater_Turn_Zero.json`, based on the last fully populated turn-zero Crash Site save. Ashton starts with its original St. Paul foothold (to avoid cityless-civ elimination), **one** World-Eater unit on tile `(4,12)`, no other Ashton units, and the entire enemy world's cities and armies preserved. Only the new companion mod is added as a ruleset dependency. Your existing saves are unchanged.

**Install**: install Veilfall, then download the companion mod from its own URL, or place the inner `Veilfall World Eater Test` folder directly under `mods`. Then load the scenario save, test abilities and scale. This is deliberately NOT a release to Veilfall main.
