# Veilfall Earth Maps

Maps-only add-on for Unciv. Requires the Veilfall extension mod. Does not replace Veilfall.

Use Unciv > Mods > Download mod from URL, with the direct archive URL. When installed, select the map named Veilfall Earth 240x120 - Test Game TSL in New Game > Map > Custom, with Veilfall enabled. Use Select players from starting locations.

First in-game load and device performance have not been verified.
